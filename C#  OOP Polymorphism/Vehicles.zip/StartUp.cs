﻿using System;
using System.Linq;
using System.Collections.Generic;

namespace Vehicles
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            string[] carTockens = Console.ReadLine().Split().ToArray();
            string[] truckTockens = Console.ReadLine().Split().ToArray();

            Vehicle car = new Car(double.Parse(carTockens[1]), double.Parse(carTockens[2]));
            Vehicle truck = new Truck(double.Parse(truckTockens[1]), double.Parse(truckTockens[2]));

            int numberOfCommands = int.Parse(Console.ReadLine());
            for (int i = 0; i < numberOfCommands; i++)
            {
                string[] line = Console.ReadLine().Split();
                string command = line[0];
                string type = line[1];
                double amount = double.Parse(line[2]);

                if (command is "Drive")
                {
                    if (type is "Car")
                    {
                        CanDrive(car, amount);
                    }
                    else
                    {
                        CanDrive(truck, amount);
                    }
                }
                else
                {
                    if (type is "Car")
                    {
                        car.Refuel(amount);
                    }
                    else
                    {
                        truck.Refuel(amount);
                    }
                }
            }

            Console.WriteLine($"Car: {car.FuelQuantity:F2}");
            Console.WriteLine($"Truck: {truck.FuelQuantity:F2}");
        }

        public static void CanDrive(Vehicle vehicle, double distance)
        {
            bool canDrive = vehicle.CanDrive(distance);
            string vehicleType = vehicle.GetType().Name;
            string result = canDrive 
                ? $"{vehicleType} travelled {distance} km" 
                : $"{vehicleType} needs refueling";
            Console.WriteLine(result);
        }
    }
}
