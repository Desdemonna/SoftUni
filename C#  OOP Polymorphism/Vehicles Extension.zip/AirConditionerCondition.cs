﻿using System;
using System.Collections.Generic;
using System.Text;

public enum AirConditionerCondition
{
    Off,
    On
}